#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import subprocess
import os

# 所有需要生成语音的文本列表（必须与 TTS.txt 完全一致）
TEXTS = [
    '你好胡椒粉哈开发法克利夫兰，欢迎您的到来！有什么需要帮助的吗？',      # 1
    '好的，请跟我来。',                                   # 2
    '北京，中国首都，千年古都与现代都市交融，尽显独特魅力。这里有宏伟的故宫、绵延的长城等历史古迹，见证着岁月的沧桑变迁。',  # 3
    '这里就是北京馆啦，我要继续回去工作啦！',              # 4
    '广州，别称羊城、花城，广东省会。历史悠久，美食诱人，经济发达，是充满魅力与活力的国家中心城市和粤港澳大湾区核心。',  # 5
    '这里就是广州馆啦，我要继续回去工作啦！',              # 6
    '吉林省，简称 "吉"，地处东北中部，与俄、朝接壤。是重要商品粮基地与老工业基地，有长白山等美景，人文风情浓郁。',  # 7
    '这里就是吉林馆啦，我要继续回去工作啦！',              # 8
    '深圳,是广东副省级市、经济特区。毗邻香港,经济发达,创新力强,有众多世界500 强企业，是粤港澳大湾区中心城市。',  # 9
    '这里就是深圳馆啦，我要继续回去工作啦！',              # 10
    '上海，简称 "沪" 或 "申"，是中国直辖市，位于长江入海口，是国际经济、金融、贸易、航运、科技创新中心，有独特海派文化。',  # 11
    '这里就是上海馆啦，我要继续回去工作啦！',              # 12
    '你好，管理员翁佳亮',                                  # 13
    '开始执行巡检任务',                                    # 14
    '北京馆未放置灭火器。',                                # 15
    '在北京馆发现火源。',                                  # 16
    '广州馆未放置灭火器。',                                # 17
    '在广州馆发现火源。',                                  # 18
    '吉林馆未放置灭火器。',                                # 19
    '在吉林馆发现火源。',                                  # 20
    '深圳馆未放置灭火器。',                                # 21
    '在深圳馆发现火源。',                                  # 22
    '上海馆未放置灭火器。',                                # 23
    '在上海馆发现火源。',                                  # 24
]

def generate_tts():
    output_dir = "/home/reicom2025/ros_workspace/src/TTS"
    os.makedirs(output_dir, exist_ok=True)
    
    # 生成 TTS.txt（格式：序号 内容，没有点号）
    tts_file = os.path.join(output_dir, "TTS.txt")
    with open(tts_file, 'w', encoding='utf-8') as f:
        for i, text in enumerate(TEXTS, 1):
            f.write(f"{i} {text}\n")  # 修改：去掉点号，只留空格
    
    print(f"✅ TTS.txt 已生成，共 {len(TEXTS)} 条")
    print("=" * 60)
    
    # 生成 MP3
    success_count = 0
    skip_count = 0
    fail_count = 0
    
    for i, text in enumerate(TEXTS, 1):
        mp3_file = os.path.join(output_dir, f"{i}.mp3")
        
        # 如果文件已存在，跳过
        if os.path.exists(mp3_file):
            print(f"⏭️  [{i}/24] {i}.mp3 已存在，跳过")
            skip_count += 1
            continue
        
        print(f"🔄 [{i}/24] 生成 {i}.mp3: {text[:30]}{'...' if len(text) > 30 else ''}")
        
        try:
            cmd = [
                "edge-tts",
                "--voice", "zh-CN-XiaoxiaoNeural",
                "--text", text,
                "--write-media", mp3_file
            ]
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            print(f"✅ 成功生成 {i}.mp3")
            success_count += 1
        except subprocess.CalledProcessError as e:
            print(f"❌ 生成 {i}.mp3 失败: {e.stderr if e.stderr else '未知错误'}")
            fail_count += 1
        except FileNotFoundError:
            print("❌ 找不到 edge-tts 命令，请先安装: pip install edge-tts")
            return
        except Exception as e:
            print(f"❌ 生成 {i}.mp3 时发生异常: {str(e)}")
            fail_count += 1
    
    # 打印统计信息
    print("=" * 60)
    print(f"📊 生成完成！成功: {success_count}, 跳过: {skip_count}, 失败: {fail_count}")
    print("=" * 60)

if __name__ == "__main__":
    generate_tts()